<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require 'config/Database.php';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT * FROM posts WHERE id = $id";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $post = $result->fetch_assoc();
            echo json_encode($post);
        } else {
            echo json_encode(["message" => "Post not found"]);
        }
    } else {
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        $limit = 10;
        $offset = ($page - 1) * $limit;
        $sql = "SELECT * FROM posts LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);
        $posts = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
            }
        }
        echo json_encode(["posts" => $posts]);
    }
}
?>